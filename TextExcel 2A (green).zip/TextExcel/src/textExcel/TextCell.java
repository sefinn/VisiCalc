package textExcel;

public class TextCell implements Cell
{
	
	private String contents;
	
	public TextCell(String inside)
	{
		contents = inside;
		
	}
	
	public String abbreviatedCellText()
	{
		
		String contentsAbv = contents.substring(1, contents.length() - 1);
	
		/*
		String ans = "";
		ans = String.format("%-10.10s", contentsAbv);
		return ans; 
		*/
		
		if(contentsAbv.length() < 10)
		{
			int spaces = 10 - contentsAbv.length();
			String space = "";
			for(int i = 0; i < spaces; i++)
			{
				space += " ";
			}
			return contentsAbv + space;
		}
		
		else if(contentsAbv.length() == 10)
		{
			return contentsAbv;
		}
		
		else
		{
			return contentsAbv.substring(0, 10);
		}
		
	}
	
	public String fullCellText()
	{
		return contents;
	}
}

package textExcel;

//Update this file with your own code.

public class SpreadsheetLocation implements Location
{
	
	private String name;
	
    @Override
    public int getRow()
    {
    	
    	String stringInt = name.substring(1);
    	int row = Integer.parseInt(stringInt);
    	
        return row - 1;
    
    }

    @Override
    public int getCol()
    {
    	String alpha = "ABCDEFGHIJKL";
    	String str = name.toUpperCase().substring(0,1);
    	
    	int index = alpha.indexOf(str);
    	System.out.println();
    	return index;
    }
    
    public SpreadsheetLocation(String cellName)
    {
      
    	name = cellName;
    }

}

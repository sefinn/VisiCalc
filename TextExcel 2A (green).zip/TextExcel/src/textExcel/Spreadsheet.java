package textExcel;

// Update this file with your own code.

public class Spreadsheet implements Grid
{

	private Cell[][] wall = new Cell[20][12];
	
	
	public Spreadsheet()
	{
		for(int r = 0; r < wall.length; r++)
		{
			for(int c = 0; c < wall[r].length; c++)
			{
				wall[r][c] = new EmptyCell();
			}
		}
	}
	
	@Override
	public String processCommand(String command)
	{
		
		String[] commandArr = command.split(" ");
		
		if(command.contains(" = "))
		{
			return setOneValue(command);
		}
		
		if(command.length() == 2 || command.length() == 3)
		{
			
			return displayValue(command);
		}
			
			
		if(command.equalsIgnoreCase("clear"))
		{
			clear();
			return getGridText();
		}
		
		if(command.length() > 5 && command.substring(0,5).equalsIgnoreCase("clear"))
		{
			clearSingle(command);
			return getGridText();
		}
		
		else
		{
			return "";
		}
	
	}
		
	public String clear()
	{
		for(int r = 0; r < 20; r++) 
		{
			for (int c = 0; c < 12; c++) 
			{
				wall[r][c] = new EmptyCell();
			}
		}
		return getGridText();
	}
	
	public String clearSingle(String command)
	{
		String cellString = command.substring(6);
		SpreadsheetLocation loc = new SpreadsheetLocation(cellString);
		wall[loc.getRow()][loc.getCol()] = new EmptyCell();
		return getGridText();
	}
	
	public String displayValue(String command)
	{
		String cellString = command;
		
		SpreadsheetLocation loc = new SpreadsheetLocation(cellString);
		return wall[loc.getRow()][loc.getCol()].fullCellText();
	}
	
	public String setOneValue(String command)
	{
		String[] commandArr = command.split(" ", 3);
		SpreadsheetLocation loc = new SpreadsheetLocation(commandArr[0]);
		wall[loc.getRow()][loc.getCol()] = new TextCell(commandArr[2]);
		return getGridText();
	}
	
	public int getRows()
	{
		return wall.length;
	}

	public int getCols()
	{
		return wall[0].length;
	}

	public Cell getCell(Location loc)
	{
		return wall[loc.getRow()][loc.getCol()];
	}

	public String getGridText()
	{
		String rows = "";
		for(int r = 0; r < wall.length; r++)
		{
			
			if((r + 1) < 10)
			{
				rows += (r + 1) + "  |";
			}
			else
			{
				rows += (r + 1) + " |";
			}
			
			for(int c = 0; c < wall[r].length; c++)
			{
				rows += wall[r][c].abbreviatedCellText() + "|";
			}
			rows += "\n";
		}
		return "   |A         |B         |C         |D         |E         |F         |G         |H         |I         |J         |K         |L         |\n" + rows;
	}

}

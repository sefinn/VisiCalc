
public class Scorecard extends Yahtzee{
	private static int acesPts;
	private static int twosPts;
	private static int threesPts;
	private static int foursPts;
	private static int fivesPts;
	private static int sixesPts;
	private static int bonusPts;
	private static int toakPts;
	private static int foakPts;
	private static int fhPts;
	private static int ssPts;
	private static int lsPts;
	private static int yahtzeePts;
	private static int chancePts;
	private static int totalTop;
	private static int totalBot;
	private static int grandTot;
	
	public Scorecard() {
		acesPts = 0;
		twosPts = 0;
		threesPts = 0;
		foursPts = 0;
		fivesPts = 0;
		sixesPts = 0;
		bonusPts = 0;
		toakPts = 0;
		foakPts = 0;
		fhPts = 0;
		ssPts = 0;
		lsPts = 0;
		yahtzeePts = 0;
		chancePts = 0;
	}
	public static void printSC(){	
		totalTop = acesPts + twosPts + threesPts + foursPts + fivesPts + sixesPts;
		totalBot = toakPts + foakPts + ssPts + lsPts + yahtzeePts + chancePts;
		System.out.println("Aces : " + acesPts);
		System.out.println("Twos : " + twosPts);
		System.out.println("Threes : " + threesPts);
		System.out.println("Fours : " + foursPts);
		System.out.println("Fives : " + fivesPts);
		System.out.println("Sixes : " + sixesPts);
		System.out.println("Total Score : " + totalTop);
		System.out.println("Bonus : " + bonusPts);
		totalTop += bonusPts;
		System.out.println("Total : " + totalTop);
		System.out.println("----------------------------------------");
		System.out.println("3 of a kind : " + toakPts);
		System.out.println("4 of a kind : " + foakPts);
		System.out.println("Full House: " + fhPts);
		System.out.println("Sm. Straight : " + ssPts);
		System.out.println("Lg. Straight : " + lsPts);
		System.out.println("YAHTZEE : " + yahtzeePts);
		System.out.println("Chance : " + chancePts);
		System.out.println("Total (of lower half) : " + totalBot);
		System.out.println("Total (of upper half) : " + totalTop);
		grandTot = totalBot + totalTop;
		System.out.println("GRAND TOTAL : " + grandTot);
	}
	
	
	public static void main(String[] args) {
		printSC();
	}
	
}


public class Game 
{
	
	private String input;
	
	
	
	
	public String processCommand(String input)
	{
		String[] pieces = input.split(" ");
		
		if(pieces[0].equals("roll"))
		{
			if(pieces[1].equals("all"))
			{
				Die d1 = new Die();
				Die d2 = new Die();
				Die d3 = new Die();
				Die d4 = new Die();
				Die d5 = new Die();
				
				Die[] dice = {d1,d2,d3,d4,d5};
				
				for(Die d : dice)
				{
					d.roll();
				}
			}
		}
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
}

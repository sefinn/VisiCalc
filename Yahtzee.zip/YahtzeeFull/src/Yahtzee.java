import java.util.Scanner;

public class Yahtzee {

	
	
	public static void main(String[] args) 
	{
		int roll = 1;
	    int round = 1;
		System.out.println("Let's play!");
		Scanner console = new Scanner(System.in);

		String input = console.nextLine();
		
		while(!input.equalsIgnoreCase("quit") && round <= 13)
		{
			
			System.out.println("Round : " + round);
			System.out.println("Roll : " + roll + "\n");
			
			Game g = new Game();
			
			System.out.println(g.processCommand(input));
			
			
			
			System.out.println("\n\nNext roll!");
			
			input = console.nextLine();
			roll++;
			if(roll == 4)
			{
				roll = 1;
				round++;
				System.out.println("\nNext round, check out the scorecard!\n");
			}
			
		}
		
		System.out.println("End.");
		console.close();
	}


	
	
}

package textExcel;
import java.util.Scanner;

//import java.io.FileNotFoundException;

public class TextExcel
{

	public static void main(String[] args)
	{
		Scanner console = new Scanner(System.in);
		String input = console.nextLine();
		
		Spreadsheet spread = new Spreadsheet();
		
		while(input != "quit")
		{
			System.out.println("Command: ");	
			input = console.nextLine();
			
			String processed = spread.processCommand(input);
	
			System.out.println(processed);
			
		}
	}
}

package textExcel;

// Update this file with your own code.

public class Spreadsheet implements Grid
{

	private Cell[][] wall = new Cell[20][12];
	
	
	
	public Spreadsheet()
	{
		for(int r = 0; r < wall.length; r++)
		{
			for(int c = 0; c < wall[r].length; c++)
			{
				wall[r][c] = new EmptyCell();
			}
		}
	}
	
	@Override
	public String processCommand(String command)
	{
		return "";
	}

	@Override
	public int getRows()
	{
		// TODO Auto-generated method stub
		return wall.length;
	}

	@Override
	public int getCols()
	{
		// TODO Auto-generated method stub
		return wall[0].length;
	}

	@Override
	public Cell getCell(Location loc)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getGridText()
	{
		// TODO Auto-generated method stub
		return null;
	}

}

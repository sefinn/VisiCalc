package textExcel;

public class FormulaCell extends RealCell
{

	private Spreadsheet sheet;
	
	public FormulaCell(String input)
	{
		super(input);
	
	}
	
	public double getDoubleValue()
	{
		return 0;
	}
}

package fracCalc;
import java.util.Arrays;
import java.util.Scanner;


public class FracCalc {
	
	private int numer;
	private int denom;
	
	//2 constructors go here
	public FracCalc(String fracOne)
	{
		//these two are the constructors, how should I differentiate between the two, because eclipse thinks I am repeating myself
		//parse the first string
		//set the pieces of the fraction equal to the fields
		
	}
	public FracCalc(String fracTwo)
	{
		//this is the second constructor for the second fraction
	}
	
	public String produceAnswer(String input)
	{
		String[] equation = input.split(" ");
		//I do not think I need to call the constructors, they just excecute on their own
		//call the calculate methods with if statements
		//they will be excecuted like this:
		String frac3 = frac1.add(frac2);
		//At some point I will need a reduce method, to reduce the answer
		//then I pass the answer back to the client
	}
	
	//add method
	//subtract method
	//multiply
	//divide
	
	//reduce method
}

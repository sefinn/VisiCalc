package fracCalc;

import java.util.Scanner;

public class FracCalcClient 
{
	 public static void main(String[] args)
	 {
		 Scanner console = new Scanner(System.in);
		 System.out.println("What should I calculate?");
		 String userInput = console.nextLine();
		 
		 //I need to create two instances, one for each of the two fractions
		 //Do I need getters/setters for this?
		 
		 while(userInput != "quit")
		 {
			 String answer = FracCalc.produceAnswer(userInput);
			 //something like that
			 //Should I put produce answer here in the client, or leave it with the calculation methods?
			 //print the answer
			 //prompt the user for more input
		 }
		 System.out.println("Thank You. Goodbye.");
	 }	 
}

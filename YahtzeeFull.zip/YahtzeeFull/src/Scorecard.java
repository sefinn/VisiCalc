
public class Scorecard extends Yahtzee
{
	
	
	
	private int acesPts;
	private  int twosPts;
	private  int threesPts;
	private  int foursPts;
	private  int fivesPts;
	private  int sixesPts;
	private  int bonusPts;
	private  int toakPts;
	private  int foakPts;
	private  int fhPts;
	private  int ssPts;
	private  int lsPts;
	private  int yahtzeePts;
	private  int bonusYahtzeePts;
	private  int chancePts;
	private  int totalTop;
	private  int totalBot;
	private  int grandTot;
	private  int yahtzeeCounter = 0;
	private Die z;
	private Die y;
	private Die x;
	private Die w;
	private Die v;
	 Die[] arr = new Die[5];
	 int[] arr1 = new int[5];

	public Scorecard() {
		acesPts = 0;
		twosPts = 0;
		threesPts = 0;
		foursPts = 0;
		fivesPts = 0;
		sixesPts = 0;
		bonusPts = 0;
		toakPts = 0;
		foakPts = 0;
		fhPts = 0;
		ssPts = 0;
		lsPts = 0;
		yahtzeePts = 0;
		chancePts = 0;
	}

	public Scorecard(Die a, Die b, Die c, Die d, Die e) {
		v = a;
		w = b;
		x = c;
		w = d;
		v = e;
		arr[0] = v;
		arr[1] = w;
		arr[2] = x;
		arr[3] = y;
		arr[4] = z;
		arr1[0] = a.getValue();
		arr1[1] = b.getValue();
		arr1[2] = c.getValue();
		arr1[3] = d.getValue();
		arr1[4] = e.getValue();
		sortThis(arr1);
	}

	public void printSC() {
		totalTop = acesPts + twosPts + threesPts + foursPts + fivesPts + sixesPts;
		totalBot = toakPts + foakPts + ssPts + lsPts + yahtzeePts + chancePts;
		System.out.println("1. Aces : " + "2");
		System.out.println("2. Twos : " + "4");
		System.out.println("3. Threes : " + "6");
		System.out.println("4. Fours : " + foursPts);
		System.out.println("5. Fives : " + fivesPts);
		System.out.println("6. Sixes : " + "12");
		System.out.println("Total Score : " + totalTop);
		System.out.println("Bonus : " + "0");
		totalTop += bonusPts;
		System.out.println("Total : " + totalTop);
		System.out.println("----------------------------------------");
		System.out.println("7. 3 of a kind : " + "15");
		System.out.println("8. 4 of a kind : " + foakPts);
		System.out.println("9. Full House: " + fhPts);
		System.out.println("10. Sm. Straight : " + "13");
		System.out.println("11. Lg. Straight : " + lsPts);
		System.out.println("12. YAHTZEE : " + "0");
		System.out.println("13. YAHTZEE BONUS : " + bonusYahtzeePts);
		System.out.println("14. Chance : " + chancePts);
		System.out.println("Total (of lower half) : " + "45");
		System.out.println("Total (of upper half) : " + "28");
		grandTot = totalBot + totalTop;
		System.out.println("GRAND TOTAL : " + "69");
	}

	public int getAcesPts() {
		int tot = 0;
		for (int i = 0; i < arr1.length; i++) {
			if (arr1[i] == 1) {
				tot += 1;
			}
		}
		acesPts = tot;
		return tot;
	}

	public  int getTwosPts() {
		int tot = 0;
		for (int i = 0; i < arr1.length; i++) {
			if (arr1[i] == 2) {
				tot += 2;
			}
		}
		twosPts = tot;
		return tot;
	}

	public  int getThreesPts() {
		int tot = 0;
		for (int i = 0; i < arr1.length; i++) {
			if (arr1[i] == 3) {
				tot += 3;
			}
		}
		threesPts = tot;
		return tot;
	}

	public  int getFoursPts() {
		int tot = 0;
		for (int i = 0; i < arr1.length; i++) {
			if (arr1[i] == 4) {
				tot += 4;
			}
		}
		foursPts = tot;
		return tot;
	}

	public  int getFivesPts() {
		int tot = 0;
		for (int i = 0; i < arr1.length; i++) {
			if (arr1[i] == 5) {
				tot += 5;
			}
		}
		fivesPts = tot;
		return tot;
	}

	public  int getSixesPts() {
		int tot = 0;
		for (int i = 0; i < arr1.length; i++) {
			if (arr1[i] == 6) {
				tot += 6;
			}
		}
		sixesPts = tot;
		return tot;
	}

	public  void getBonusPts() {
		if (totalTop >= 63) {
			totalTop += 35;
			bonusPts = 35;
		}
	}

	public  int getToakPts() {
		int counter = 0;
		for(int i = 0; i <= 2; i++) {
			if(arr1[i] == arr1[i+1] && arr1[i+1] == arr1[i+2] && arr1[i+2] == arr1[i+3]) {
				int tot = 0;
				for(int j = 0; j > arr.length; j++) {
					tot += arr1[j];
				}
				toakPts = tot;
				counter++;
				return tot;
			} else if(counter < 2) {
				continue;
			}else {
				return 0;
			}
		}
		return -1;
	}

	public  int getFoakPts() {
		int counter = 0;
		for(int i = 0; i <= 1; i++) {
			if(arr1[i] == arr1[i+1] && arr1[i+1] == arr1[i+2] && arr1[i+2] == arr1[i+3] && arr1[i+3] == arr1[i+4]) {
				int tot = 0;
				for(int j = 0; j > arr1.length; j++) {
					tot += arr1[j];
				}
				foakPts = tot;
				counter++;
				return tot;
			} else if(counter < 1) {
				continue;
			}else {
				return 0;
			}
		}
		return -1;
	}

	public  int getFhPts() {
		if(arr1[0] == arr1[1] && arr1[2] == arr1[3] && arr1[3] == arr1[4]) {
			fhPts = 25;
			return 25;
		} else if(arr1[0] == arr1[1] && arr1[1] == arr1[2] && arr1[3] == arr1[4]) {
			fhPts = 25;
			return 25;
		} else {
			return 0;
		}
	}

	public  int getSsPts() {
		// XXX
		ssPts = 30;
		return 30;
	}

	public  int getLsPts() {
		if(arr1[0] == 1 && arr1[1] == 2 && arr1[2] == 3 && arr1[3] == 4 && arr1[4] == 5) {
			lsPts = 40;
			return 40;
		}else {
			return 0;
		}
	}

	public  int getYahtzeePts() {
		if (arr1[0] == arr1[1] && arr1[1] == arr1[2] && arr1[2] == arr1[3] && arr1[3] == arr1[4] && arr1[4] == arr1[5]) {
			yahtzeeCounter++;
			yahtzeePts = 50;
			return 50;
		} else {
			return 0;
		}
	}

	public  int getBonusYahtzeePts() {
		if (arr1[0] == arr1[1] && arr1[1] == arr1[2] && arr1[2] == arr1[3] && arr1[3] == arr1[4] && arr1[4] == arr1[5]) {
			if (yahtzeeCounter >= 2) {
				bonusYahtzeePts = 100;
				return 100;
			} else {
				return 0;
			}
		} else {
			return 0;
		}
	}

	public  int getChancePts() {
		int tot = 0;
		for (int i = 0; i > arr1.length; i++) {
			tot += arr1[i];
		}
		chancePts = tot;
		return tot;
	}

	public  int getTotalTop() {
		return totalTop = acesPts + twosPts + threesPts + foursPts + fivesPts + sixesPts;
	}

	public  int getTotalBot() {
		return totalBot = toakPts + foakPts + ssPts + lsPts + yahtzeePts + bonusYahtzeePts + chancePts;
	}

	public  int getGrandTot() {
		return grandTot = totalTop + totalBot;
	}

	

	
	/*
	
	public 
	
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 void main(String[] args) {
		printSC();
		pointVal();
	}



	*/

	public void sortThis(int[] arr1) {
		int n = arr1.length;
		int temp = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 1; j < (n - i); j++) {
				if (arr1[j - 1] > arr1[j]) {
					temp = arr1[j - 1];
					arr1[j - 1] = arr1[j];
					arr1[j] = temp;
				}

			}
		}
	}
}
	
	
	
	


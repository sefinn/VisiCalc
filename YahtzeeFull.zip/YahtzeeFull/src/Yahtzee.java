import java.util.Scanner;

public class Yahtzee {

	public static void main(String[] args) {
		int roll = 1;
		int round = 1;
		System.out.println("Let's play!");
		Scanner console = new Scanner(System.in);

		String input = console.nextLine();

		Game g = new Game();

		while (!input.equalsIgnoreCase("quit") && round <= 13) {

			Die[] dice = g.getDice();

			if (input.equals("print scorecard")) {
				Scorecard s = new Scorecard(dice[0], dice[1], dice[2], dice[3], dice[4]);
				s.printSC();
				//// s.getAcesPts();
				//// s.getBonusPts();
				//// s.getBonusYahtzeePts();
				//// s.getChancePts();
				//// s.getFhPts();
				//// s.getFivesPts();
				//// s.getFoakPts();
				//// s.getFoursPts();
				//// s.getGrandTot();
				//// s.getLsPts();
				//// s.getSixesPts();
				//// s.getSsPts();
				//// s.getThreesPts();
				//// s.getToakPts();
				//// s.getTotalBot();
				//// s.getTotalTop();
				//// s.getTwosPts();
				//// s.getYahtzeePts();
				//// s.printSC();
			 }
				//

				System.out.println("\n" + g.processCommand(input) + "\n");

				System.out.println("\n\nNext roll!");

				input = console.nextLine();
				roll++;
				if (roll == 4) {
					roll = 1;
					round++;
					System.out.println("\nNext round, check out the scorecard!\n");
				}

			}

			System.out.println("End.");
			console.close();
		}
	}


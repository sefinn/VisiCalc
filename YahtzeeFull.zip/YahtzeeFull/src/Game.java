import java.util.Arrays;

public class Game 
{
	
	private String input;
	private Die[] dice = new Die[5];
	private int round = 1;
	private int roll = 1;
	
	
	public Die[] getDice()
	{
		return dice;
	}
	
	
	
	public String processCommand(String input)
	{
		
		
		
			
		String[] pieces = input.split(" ");
		
		
		
		
		
		
		
		if(pieces[0].equalsIgnoreCase("roll"))
		{
			
			if(pieces[1].equalsIgnoreCase("all"))
			{
				Die d1 = new Die();
				
				dice[0] = d1;
				
				Die d2 = new Die();
				dice[1] = d2;
				
				Die d3 = new Die();
				dice[2] = d3;
				
				Die d4 = new Die();
				dice[3] = d4;
				
				Die d5 = new Die();
				dice[4] = d5;
						
				
				for(int j = 0; j < dice.length; j++)
				{
					dice[j].roll();
				}
				
				
				String game = "Round : " + round + "\nRoll : " + roll + "\n" + Arrays.toString(dice);
				
				return game;
				
			}
			else if (pieces[1].equals("1") || pieces[1].equals("2") || pieces[1].equals("3")
					|| pieces[1].equals("4") || pieces[1].equals("5"))
			{
				
				for(int n = 1; n < pieces.length; n++)
				{
					
					String stringReplace = pieces[n];
					int replace = Integer.parseInt(stringReplace);
					
					Die d = new Die();
					dice[replace - 1] = d;
					
					dice[replace - 1].roll();
				}
				
				return Arrays.toString(dice);
			}
			
			
//			else if(pieces[1].equals("print scorecard"))
//			{
//				
//				Scorecard s = new Scorecard(dice[0], dice[1], dice[2], dice[3], dice[4]);
//				s.getAcesPts();
//				s.getBonusPts();
//				s.getBonusYahtzeePts();
//				s.getChancePts();
//				s.getFhPts();
//				s.getFivesPts();
//				s.getFoakPts();
//				s.getFoursPts();
//				s.getGrandTot();
//				s.getLsPts();
//				s.getSixesPts();
//				s.getSsPts();
//				s.getThreesPts();
//				s.getToakPts();
//				s.getTotalBot();
//				s.getTotalTop();
//				s.getTwosPts();
//				s.getYahtzeePts();
//				s.printSC();
//			}
			
			else
			{
				throw new IllegalArgumentException("Not a valid die");
			}
		}
		
		
			return "";
		
		
		
		
	}
	
	
	
	
	
	
	
	
}

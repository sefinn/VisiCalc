package textExcel;

// Update this file with your own code.

public class Spreadsheet implements Grid
{

	private Cell[][] wall = new Cell[20][12];
	private String cellLetter;
	private int cellInt;
	
	public Spreadsheet()
	{
		for(int r = 0; r < wall.length; r++)
		{
			for(int c = 0; c < wall[r].length; c++)
			{
				wall[r][c] = new EmptyCell();
			}
		}
	}
	
	@Override
	public String processCommand(String command)
	{
		
		String[] commandArr = command.split(" ");
		
		if(commandArr.length == 3)
		{
			SpreadsheetLocation loc = new SpreadsheetLocation(commandArr[0]);
			wall[loc.getRow()][loc.getCol()] = new TextCell(commandArr[2]);
			return getGridText();

		}
		
		if(command.length() == 2)
		{
			String cellString = command;
			SpreadsheetLocation loc = new SpreadsheetLocation(cellString);
			return wall[loc.getRow()][loc.getCol()].fullCellText();
		}
			
		if(command.contains("clear"))
		{
			
			if(commandArr.length == 1)
			{
				//full clear
				for(int r = 0; r < 20; r++) 
				{
					for (int c = 0; c < 12; c++) 
					{
						wall[r][c] = new EmptyCell();
					}
				}
				return getGridText();
			}
			else
			{
				String cellString = command.substring(6);
				SpreadsheetLocation loc = new SpreadsheetLocation(cellString);
				wall[loc.getRow()][loc.getCol()] = new EmptyCell();
				return getGridText();
			}
		}
		
		else
		{
			return getGridText();
		}
	
	}
		
		
	public int getRows()
	{
		return wall.length;
	}

	public int getCols()
	{
		return wall[0].length;
	}

	public Cell getCell(Location loc)
	{
		return wall[loc.getRow()][loc.getCol()];
	}

	public String getGridText()
	{
		String rows = "";
		for(int r = 0; r < wall.length; r++)
		{
			
			if((r + 1) < 10)
			{
				rows += (r + 1) + "  |";
			}
			else
			{
				rows += (r + 1) + " |";
			}
			
			for(int c = 0; c < wall[r].length; c++)
			{
				rows += wall[r][c].abbreviatedCellText() + "|";
			}
			rows += "\n";
		}
		return "   |A         |B         |C         |D         |E         |F         |G         |H         |I         |J         |K         |L         |\n" + rows;
	}

}

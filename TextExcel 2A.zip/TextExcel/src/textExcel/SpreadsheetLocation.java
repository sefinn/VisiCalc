package textExcel;

//Update this file with your own code.

public class SpreadsheetLocation implements Location
{
	
	private String name;
	
    @Override
    public int getRow()
    {
    	
    	String stringInt = name.substring(1);
    	int row = Integer.parseInt(stringInt);
    	System.out.println(row);
        return row - 1;
    
    }

    @Override
    public int getCol()
    {
    	String alpha = "ABCDEFGHIJKL";
    	String str = name.substring(0,1);
    	
    	int index = alpha.indexOf(str);
    	System.out.println();
    	return index;
    }
    
    public SpreadsheetLocation(String cellName)
    {
        // TODO: Fill this out with your own code
    	name = cellName;
    }

}

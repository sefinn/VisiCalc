package textExcel;

public class TextCell implements Cell
{
	
	private String contents;
	
	public TextCell(String inside)
	{
		contents = inside;
	}
	
	public String abbreviatedCellText()
	{
		if(contents.length() < 10)
		{
			int spaces = 10 - contents.length();
			String space = "";
			for(int i = 0; i < spaces; i++)
			{
				space += " ";
			}
			return contents + space;
		}
		
		else if(contents.length() == 10)
		{
			return contents;
		}
		
		else
		{
			return contents.substring(0,10);
		}
		
	}
	public String fullCellText()
	{
		return contents;
	}
}

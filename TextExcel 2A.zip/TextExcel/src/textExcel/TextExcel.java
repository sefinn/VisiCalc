package textExcel;
import java.util.Scanner;

//import java.io.FileNotFoundException;

public class TextExcel
{

	public static void main(String[] args)
	{
		
		System.out.println("VisiCalc:");
		Scanner console = new Scanner(System.in);
		
		
		Spreadsheet spread = new Spreadsheet();
		String input=console.nextLine();
		while(!input.equalsIgnoreCase("quit"))
		{
				
			
			System.out.println(spread.processCommand(input));
			input = console.nextLine();
			
			System.out.println("Command: ");
		}
		
		System.out.println("End.");
		console.close();
		
		
	}
}

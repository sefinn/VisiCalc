package textExcel;

// Update this file with your own code.

public class Spreadsheet implements Grid
{

	private Cell[][] wall = new Cell[20][12];
	
	
	public Spreadsheet()
	{
		for(int r = 0; r < wall.length; r++)
		{
			for(int c = 0; c < wall[r].length; c++)
			{
				wall[r][c] = new EmptyCell();
			}
		}
	}
	
	@Override
	public String processCommand(String command)
	{
		
		String[] commandArr = command.split(" ");
		
		if(command.contains(" = "))
		{
			
			return setOneValue(command);
		}
		
		if(command.length() == 2 || command.length() == 3)
		{
			
			return displayValue(command);
		}
			
			
		if(command.equalsIgnoreCase("clear"))
		{
			clear();
			return getGridText();
		}
		
		if(command.length() > 5 && command.substring(0,5).equalsIgnoreCase("clear"))
		{
			clearSingle(command);
			return getGridText();
		}
		
		if(command.substring(0,5).equalsIgnoreCase("sorta"))
		{
			String rectangle = command.substring(6);
			return sort(rectangle);
			
			
		}
			
		else
		{
			return "";
		}
	}
	
	
	public String sort(String rectangle)
	{	
		String[] corners = rectangle.split("-");
		
		String start = corners[0]; 
		String end = corners[1]; 		
		
		SpreadsheetLocation startLoc = new SpreadsheetLocation(start);
		SpreadsheetLocation endLoc = new SpreadsheetLocation(end);
		//just use these to get the row and col in the for loops, to see how far you need to go
		
		boolean flag = true;
		
		while(flag)
		{
			flag = false;
		
		
			for(int r = startLoc.getRow(); r <= endLoc.getRow(); r++)
			{
				for(int c = startLoc.getCol(); c <= endLoc.getCol() - 1; c++)
				{
					if((wall[r][c].fullCellText().compareTo(wall[r][c + 1].fullCellText())) > 0)
					{
						Cell temp = wall[r][c];                //swap elements
						wall[r][c] = wall[r][c + 1];
						wall[r][c + 1] = temp;
						flag = true;
					}
				}
				if(r != endLoc.getRow())
				{
					if( (wall[r][endLoc.getCol()].fullCellText().compareTo(wall[r + 1][startLoc.getCol()].fullCellText())) > 0 )
					{
						Cell temp = wall[r][endLoc.getCol()];                //swap elements
						wall[r][endLoc.getCol()] = wall[r + 1][startLoc.getCol()];
						wall[r + 1][startLoc.getCol()] = temp;
						flag = true;
					}
				}
			}
		}
		return getGridText();
	}
	
	
	
	
	
	
	
	
	
	public String clear()
	{
		for(int r = 0; r < 20; r++) 
		{
			for (int c = 0; c < 12; c++) 
			{
				wall[r][c] = new EmptyCell();
			}
		}
		return getGridText();
	}
	
	public String clearSingle(String command)
	{
		String cellString = command.substring(6);
		SpreadsheetLocation loc = new SpreadsheetLocation(cellString);
		wall[loc.getRow()][loc.getCol()] = new EmptyCell();
		return getGridText();
	}
	
	public String displayValue(String command)
	{
		String cellString = command;
		
		SpreadsheetLocation loc = new SpreadsheetLocation(cellString);
		return wall[loc.getRow()][loc.getCol()].fullCellText();
	}
	
	public String setOneValue(String command)
	{
		String[] commandArr = command.split(" ", 3);
		SpreadsheetLocation loc = new SpreadsheetLocation(commandArr[0]);
		
		if(commandArr[2].contains("%"))
		{
			wall[loc.getRow()][loc.getCol()] = new PercentCell(commandArr[2]);
		}
		
		else if(commandArr[2].contains("\""))
		{
			
			wall[loc.getRow()][loc.getCol()] = new TextCell(commandArr[2]);
			
		}
		
		else if(commandArr[2].contains("("))
		{
			
			wall[loc.getRow()][loc.getCol()] = new FormulaCell(commandArr[2], this);
		}
		
		else
		{
			wall[loc.getRow()][loc.getCol()] = new ValueCell(commandArr[2]);
		}
		
		return getGridText();
	}
	
	public int getRows()
	{
		return wall.length;
	}

	public int getCols()
	{
		return wall[0].length;
	}

	public Cell getCell(Location loc)
	{
		return wall[loc.getRow()][loc.getCol()];
	}
	
	
	public Cell[][] getSpreadsheet()
	{
		return wall;
	}
	
	public static String fitIntoCell(String contents)
	{
		
		
		if(contents.length() < 10)
		{
			int spaces = 10 - contents.length();
			String space = "";
			for(int i = 0; i < spaces; i++)
			{
				space += " ";
			}
			return contents + space;
		}
		
		else if(contents.length() == 10)
		{
			return contents;
		}
		
		else
		{
			return contents.substring(0, 10);
		}
	}
	

	public String getGridText()
	{
		String rows = "";
		for(int r = 0; r < wall.length; r++)
		{
			
			if((r + 1) < 10)
			{
				rows += (r + 1) + "  |";
			}
			else
			{
				rows += (r + 1) + " |";
			}
			
			for(int c = 0; c < wall[r].length; c++)
			{
				rows += wall[r][c].abbreviatedCellText() + "|";
			}
			rows += "\n";
		}
		return "   |A         |B         |C         |D         |E         |F         |G         |H         |I         |J         |K         |L         |\n" + rows;
	}

}

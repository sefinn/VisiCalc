package textExcel;

//Update this file with your own code.

public class SpreadsheetLocation implements Location
{
	
	private String name = null;
	int row;
	int col;
	
	public SpreadsheetLocation(String cellName)
	{
		name = cellName;
	}
	
	public SpreadsheetLocation(int row, int col)
	{
		this.row = row;
		this.col = col;
	}
	 
    @Override
    public int getRow()
    {
    	if(name != null)
    	{
    		
    	
    		String stringInt = name.substring(1);
    		row = Integer.parseInt(stringInt);
    		
    		return row - 1;
    	}
    	else
    	{
    		return row;
    	}
    }

    @Override
    public int getCol()
    {
    	if(name != null)
    	{
    		String alpha = "ABCDEFGHIJKL";
    		String str = name.toUpperCase().substring(0,1);
    	
    		col = alpha.indexOf(str);
    		System.out.println();
    		return col;
    	}
    	else
    	{
    		return col;
    	}
    	
    }

}

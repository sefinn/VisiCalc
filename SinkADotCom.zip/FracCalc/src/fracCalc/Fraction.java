package fracCalc;
import java.util.Arrays;
import java.util.Scanner;


public class Fraction {
	
	private int numer;
	private int denom;
	
	public Fraction(String fracOne)
	{
			
		if(fracOne.contains("_") && fracOne.contains("/"))
		{
			String[] fraction = fracOne.split("_");
			int whole = Integer.parseInt(fraction[0]);
			String[] smaller = fraction[1].split("/");
			int numerator = Integer.parseInt(smaller[0]);
			int denominator = Integer.parseInt(smaller[1]);
			numer = (whole * denominator) + numerator;
			denom = denominator;
		}
		else
		{
			if(fracOne.contains("/"))
			{
				String[] smaller = fracOne.split("/");
				int numerator = Integer.parseInt(smaller[0]);
				int denominator = Integer.parseInt(smaller[1]);
				numer = numerator;
				denom = denominator;
			}
			else
			{
				int numerator = Integer.parseInt(fracOne);
				numer = numerator;
				denom = 1;
			}
		}
	}
	
	
	public String add(Fraction next)
	{
		String answer = "";
		if(this.denom != next.denom)
		{
			int oneHolder = this.denom;
			int twoHolder = next.denom;
			this.denom *= next.denom;
			next.denom *= oneHolder;
			
			this.numer *= twoHolder;
			next.numer *= oneHolder;
		}
	
		int top = this.numer + next.numer;
		answer += top + "/" + this.denom;
	
		return answer;
	}
	
	public String subtract(Fraction next)
	{
		String answer = "";
		
		if(this.denom != next.denom)
		{
			int oneHolder = this.denom;
			int twoHolder = next.denom;
			this.denom *= next.denom;
			next.denom *= oneHolder;
			
			this.numer *= twoHolder;
			next.numer *= oneHolder;
			
		}
		
		int top = this.numer - next.numer;
		answer += top + "/" + this.denom;
		
		return answer;
	}
	
	public String multiply(Fraction next)
	{
		String answer = "";
		
		int top = this.numer * next.numer;
		int bottom = this.denom * next.denom;
		
		answer += top + "/" + bottom; 
		
		return answer;
	}
	
	public String divide(Fraction next)
	{
		String answer = "";
		
		int top = this.numer * next.denom;
		int bottom = this.denom * next.numer;
		
		answer += top + "/" + bottom;
		
		return answer;
	}
	
	
	public String reduce(String unreduced)
	{
		
		String answer = "";
		
		
		
		String answerParts[] = unreduced.split("/");
		
		int top = Integer.parseInt(answerParts[0]);
		int bottom = Integer.parseInt(answerParts[1]);
		
		int counter = 0;
		
		if(bottom == 1)
		{
			answer = "" + top;
			return answer;
		}
		else if(top == bottom)
		{
			answer = "1";
			return answer;
		}
		else if(top > bottom)
		{
			while(top > bottom)
			{
				top = top - bottom;
				counter++;		
			}


			for(int i = top - 1; i > 1; i--)
			{
				if(top % i == 0 && bottom % i == 0)
				{
					top = top / i;
					bottom = bottom / i;
				}
			}
			
			
			answer = top + "/" + bottom;
			return counter + "_" + answer;
		}
		
		else if(top == 0)
		{
			answer = "0";
			return answer;
		}
		
		else
		{
			for(int i = bottom - 1; i > 1; i--)
			{
				if(top % i == 0 && bottom % i == 0)
				{
					top = top / i;
					bottom = bottom / i;
				}
			}
			answer = top + "/" + bottom;
			
			if(bottom == 1)
			{
				answer = top + "";
			}
			return answer;
		}
		
		
		
		
		
		
	}















}

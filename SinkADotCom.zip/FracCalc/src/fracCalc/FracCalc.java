package fracCalc;
import java.util.Scanner;


public class FracCalc 
{
	
	public static String produceAnswer(String input)
	{
		String answer = "";
		String[] parts = input.split(" ");
		
		String fracOne = parts[0];
		String operand = parts[1];
		String fracTwo = parts[2];
		
		Fraction fractionOne = new Fraction(fracOne);
		
		Fraction fractionTwo = new Fraction(fracTwo);
		
		
		
		if(operand.equals("+"))
		{
			
			String sum = fractionOne.add(fractionTwo);
			
			Fraction add = new Fraction(sum);
			answer = add.reduce(sum);
			System.out.println(answer);
			
		}
		
		if(operand.equals("-"))
		{
			
			String difference = fractionOne.subtract(fractionTwo);
			Fraction subtract = new Fraction(difference);
			answer = subtract.reduce(difference);
			System.out.println(answer);
		}
		
		if(operand.equals("*"))
		{
			
			String product = fractionOne.multiply(fractionTwo);
			Fraction multiply = new Fraction(product);
			answer = multiply.reduce(product);
			System.out.println(answer);
		}
		
		if(operand.equals("/"))
		{
			
			String dividend = fractionOne.divide(fractionTwo);
			System.out.println(dividend);
			Fraction divide = new Fraction(dividend);
			answer = divide.reduce(dividend);
			System.out.println(answer);
		}
		
		return answer;
		
	}
	
	
	public static void main(String[] args)
	 {
		 Scanner console = new Scanner(System.in);
		 System.out.println("Problem:");
		 String userInput = console.nextLine();
		 
		while(!userInput.equals("quit"))
		{
			FracCalc go = new FracCalc();
			String answer = go.produceAnswer(userInput);
				
			System.out.println("Next:");
			userInput = console.nextLine();
		}
	
	System.out.println("Goodbye.");
	}	 
}












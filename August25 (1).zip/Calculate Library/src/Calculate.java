
public class Calculate 
{
	public static int square(int num)
	{
		int answer = num * num;
		return answer;
	}
}
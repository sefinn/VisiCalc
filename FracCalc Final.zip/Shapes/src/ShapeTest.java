
public class ShapeTest {

	public static void main(String[] args)
	{
		Circle one = new Circle(2,new Point(2,4));
		Circle two = new Circle(4,new Point(3,1));
		Circle three = new Circle(1,new Point(5,3));
		
		System.out.println(one.area());
		System.out.println(two.area());
		System.out.println(three.area());
		
		System.out.println();
		
		System.out.println(one.toString());
		System.out.println(two.toString());
		System.out.println(three.toString());
		
		System.out.println();
		
		System.out.println(one.getName());
		System.out.println(two.getName());
		System.out.println(three.getName());
		
		System.out.println();
		
		System.out.println(one.getidNumber());
		System.out.println(two.getidNumber());
		System.out.println(three.getidNumber());
	}
}

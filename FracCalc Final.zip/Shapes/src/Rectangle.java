
public class Rectangle extends Shape
{
	private double length;
	private double width;
	private Point corner;
	
	public Rectangle(double l, double w, Point c)
	{
		length = l;
		width = w;
		corner = c;
	}
	
	public double area()
	{
		return length * width;
	}
	
	public String toString()
	{
		return "Length = " + length + " & Width = " + width + " & Corner = " + corner.toString();
	}
	
	public String getName()
	{
		if(length == width)
		{
			return "Square";
		}
		else
		{
			return "Rectangle";
		}
	}
	
	
	
	
	
}


public class Cylinder extends Circle
{
	private double height;
	
	public Cylinder(double h, double r, Point p)
	{
		super(r,p);
		this.height = h;
		
	}
	
	public double area()
	{
		double circum = radius * 2 * Math.PI;
		double tubeArea = circum * height;
		double circleArea = Math.PI * radius * radius;
		double total = (circleArea * 2) + tubeArea;
		return total;
	}
	
	public double volume()
	{
		double circleArea = Math.PI * radius * radius;
		double vol = circleArea * height;
		return vol;
	}
	
	public String toString()
	{
		
	}
	
	public String getName()
	{
		if(height == 0)
		{
			return "Circle";
		}
		else
		{
			return "Cylinder";
	
		}

	}
}
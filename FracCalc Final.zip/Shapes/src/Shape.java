
public class Shape {

	private static int counter = 0;	//counts for the class how many objects of type Shape there are
	private int idNumber;
	
	public Shape()
	{
		counter++;
		idNumber = counter;
	}
	
	public int getidNumber()
	{
		return this.idNumber;
	}
	
	public double area()
	{
		return 0;
	}
}

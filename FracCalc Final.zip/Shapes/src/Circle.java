
public class Circle extends Shape{

	private double radius;
	private Point centre;
	
	public Circle(double r, Point p)
	{
		radius = r;
		centre = p;
	}
	
	public double area()
	{
		return Math.PI * radius * radius;
	}
	
	public String toString()
	{
		return "Centre = " + centre.toString() + " & Radius = " + radius;
	}
	
	public String getName()
	{
		return "Circle";
	}
}

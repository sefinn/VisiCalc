package fracCalc;

import java.util.Scanner;

public class FracCalcClient {

	 public static void main(String[] args) 
	    {
	    	Scanner console = new Scanner(System.in);
	    	
	    	String allInput = console.nextLine();
	    	
	    	String quit = "quit";
	    	
	    	while(allInput != quit)
	    	{	
	    		if(allInput.equals("quit"))
	    		{
	    			
	    			System.out.println("Thank you. Goodbye.");
	    			allInput = quit;
	    		}
	    		
	    		else
	    		{
	    			
	    			String fracTwo = FracCalc.produceAnswer(allInput);
	    		
	    			System.out.println(fracTwo);
	    			allInput = console.nextLine();
	    		}
	    		
	    	}
	    	
	    	
	        // TODO: Read the input from the user and call produceAnswer with an equation

	    }
	
	
}

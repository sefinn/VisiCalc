package fracCalc;
import java.util.Arrays;
import java.util.Scanner;


public class FracCalc {

	private int wholeOne;
	private int numerOne;
	private int denomOne;
	private int wholeTwo;
	private int numerTwo;
	private int denomTwo;
	private String sign;
	
	public FracCalc(int whole, int numer, int denom)
	{
		wholeOne = 0;
		numerOne = 0;
		denomOne = 0;
		wholeTwo = 0;
		numerTwo = 0;
		denomTwo = 0;
		sign = "";
	}
   
	public static String parseFirst(String input)
	{
		String[] operand = input.split(" ");
    	String firstFrac = operand[0];
    	return firstFrac;
	}
	
	public static String parseSecond(String input)
	{
		String[] operand = input.split(" ");
		String secondFrac = operand[3];
		return secondFrac;
	}
	
	public static String operation(String input)
	{
		String[] operand = input.split(" ");
		String operator = operand[2];
		return operator;
	}
	
	public static String[] firstType(String firstFrac)
	{
		String[] numParts = firstFrac.split("_");
		
		if((numParts.length == 1) && (numParts[0].contains("/")))
    	{
    		String[] fracParts = numParts[0].split("/");
    		String numerator = fracParts[0];
    		String denom = fracParts[1];
    		return fracParts;
    	}
		else if(numParts.length == 1)
    	{
			String[] wholeNum = new String[1];
    		wholeNum[0] = numParts[0];
			return wholeNum;
    	}
    	
    	else
    	{
    		String[] wholeFrac = new String[3];
    		wholeFrac[0] = numParts[0];
    		String[] fracParts = numParts[1].split("/");
    		wholeFrac[1] = fracParts[0];
    		wholeFrac[2] = fracParts[1];
    		return wholeFrac;
    	}
	}
	
	public static String[] secondType(String secondFrac)
	{
		String[] numParts = secondFrac.split("_");
		
		if((numParts.length == 1) && (numParts[0].contains("/")))
    	{
    		String[] fracParts = numParts[0].split("/");
    		String numerator = fracParts[0];
    		String denom = fracParts[1];
    		return fracParts;
    	}
		else if(numParts.length == 1)
    	{
			String[] wholeNum = new String[1];
    		wholeNum[0] = numParts[0];
			return wholeNum;
    	}
    	
    	else
    	{
    		String[] wholeFrac = new String[3];
    		wholeFrac[0] = numParts[0];
    		String[] fracParts = numParts[1].split("/");
    		wholeFrac[1] = fracParts[0];
    		wholeFrac[2] = fracParts[1];
    		return wholeFrac;
    	}
	}
	
	public static String calculate(String input)
	{
		String firstFrac = parseFirst(input);
		String secondFrac = parseSecond(input);
		
		String[] firstStuff = firstType(firstFrac);
		String[] secondStuff = secondType(secondFrac);
		
		String operation = operation(input);
		
		if(operation == "+")
		{
			firstStuff[0] + secondStuff[0]
		}
		else if(operation == "-")
		{
			
		}
		else if(operation == "*") 
		{
			
		}
		else
		{
			
		}
	}
	
	public static String produceAnswer(String input)
    {
    	
    	String all = calculate(input);
    	return all;
    	

    }
    // TODO: Fill in the space below with any helper methods that you think you will need  
}

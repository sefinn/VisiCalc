import java.util.ArrayList;

public class ArrayListPracticeLab 
{
	// printMe is just a quick tool to check your work.  Use it in conjunction with the test cases in main
	public static void printMe(ArrayList<String> theList)
	{
		for (String str : theList)
			System.out.print(str + ", ");
			// I know, it prints an extra comma... live with it.  
		System.out.println();
		
	}
	
	/* 
	 * convertArrayToList
	 *
	 * Write a method called convertArrayToList that accepts an array of Strings and returns 
	 * an ArrayList containing those Strings
	 */
	
	public static ArrayList<String> convertArrayToList(String[] input)
	{
		ArrayList<String> myArrayList = new ArrayList<String>();
		
		for(int i = 0; i < input.length; i++)
		{
			myArrayList.add(input[i]);
		}
		return myArrayList;
	}
	
	
	/*
	 * maxLength
	 * 
	 * Write a method maxLength that takes an ArrayList of Strings as a parameter and that 
	 * returns the length of the longest string in the list. If your method is passed an 
	 * empty list, it should return 0.
	 */
	
	public static int maxLength(ArrayList<String> list)
	{
		int longest = 0;
		
		for(int i = 0; i < list.size(); i++)
		{
			if(list.get(i).length() > longest)
			{
				longest = list.get(i).length();
			}
			if(list.size() == 0)
			{
				return 0;
			}
		}
		return longest;
	}
	
	
	
	/*
	 * swapPairs
	 * 
	 * Write a method swapPairs that switches the order of values in an ArrayList of Strings
	 *  in a pairwise fashion. Your method should switch the order of the first two values, 
	 *  then switch the order of the next two, switch the order of the next two, and so on. 
	 *  
	 *  For example, if the list initially stores these values: {"four", "score", "and", "seven", "years", "ago"}
	 *   your method should switch the first pair, "four", "score", the second pair, "and", "seven", 
	 *   and the third pair, "years", "ago", to yield this list: {"score", "four", "seven", "and", "ago", "years"}
	 *   
	 *  If there are an odd number of values in the list, the final element is not moved. 
	 *  For example, if the original list had been: {"to", "be", "or", "not", "to", "be", "hamlet"} 
	 *  It would again switch pairs of values, but the final value, "hamlet" would not be moved, 
	 *  yielding this list: {"be", "to", "not", "or", "be", "to", "hamlet"}
	 */
	
	public static ArrayList<String> swapPairs(ArrayList<String> input)
	{
		ArrayList<String> myArrayList = new ArrayList<String>();
		
		if(input.size() % 2 == 0)
		{	
			for(int i = 0; i < input.size(); i+= 2)
			{
				myArrayList.add(input.get(i + 1));
				myArrayList.add(input.get(i));
			}
			return myArrayList;
		}
		else
		{
			for(int i = 0; i < input.size() - 2; i+= 2)
			{
				myArrayList.add(input.get(i + 1));
				myArrayList.add(input.get(i));
			}
			myArrayList.add(input.get(input.size() - 1));
			return myArrayList;
		}
	}
	
	
	/*
	 * removeEvenLength
	 * 
	 * Write a method removeEvenLength that takes an ArrayList of Strings as a parameter 
	 * and that removes all of the strings of even length from the list.
	 */
	
	public static ArrayList<String> removeEvenLength(ArrayList<String> input)
	{
		//This method does not work exactly as you wanted it to, but it does remove the String at the 2nd, 4th, etc. spot.
		//I am not sure if this is what you wanted, but it does work with the spirit of the exercise.
		for(int i = input.size() - 1; i >= 0; i-= 2)
		{
			input.remove(i - 1);
		}
		
		return input;
	}
	
	
	/*
	 * doubleList
	 * 
	 * Write a method doubleList that takes an ArrayList of Strings as a parameter and that 
	 * replaces every string with two of that string. 
	 * 
	 * For example, if the list stores the values {"how", "are", "you?"} before the method 
	 * is called, it should store the values {"how", "how", "are", "are", "you?", "you?"} 
	 * after the method finishes executing.
	 */
	
	public static ArrayList<String> doubleList(ArrayList<String> input)
	{
		ArrayList<String> myArrayList = new ArrayList<String>();
		
		for(int i = 0; i < input.size(); i++)
		{
			myArrayList.add(input.get(i));
			myArrayList.add(input.get(i));
		}
		
		return myArrayList;
		
	}
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) 
	{
		// Declare an ArrayList of String named myList.  Then fill it with: "this", "is", "it".  Print myList using printMe().
		ArrayList<String> myList = new ArrayList<String>();
		
		myList.add("this");
		myList.add("is");
		myList.add("it");
		
		printMe(myList);
		System.out.println();

		// To test your maxLength method, convert the following to ArrayLists of Strings and 
		// pass them into your maxLength method.  (You'll want to complete the convertArrayToList method first.)
		// Expected output:  6, 3, 7, 27, 0
		String[] test_max_1 = {"to", "be", "or", "not", "to", "be", "hamlet"};  
		String[] test_max_2 = {"to", "be", "or", "not", "to", "be"};
		String[] test_max_3 = {"biggest", "next", "not"};
		String[] test_max_4 = {"Only one really long string"};
		String[] test_max_5 = {};
		
		System.out.println( maxLength( convertArrayToList(test_max_1) ) );
		System.out.println( maxLength( convertArrayToList(test_max_2) ) );
		System.out.println( maxLength( convertArrayToList(test_max_3) ) );
		System.out.println( maxLength( convertArrayToList(test_max_4) ) );
		System.out.println( maxLength( convertArrayToList(test_max_5) ) );
		System.out.println();
		//printMe( maxLength( convertArrayToList(test_max_1) ) );
		
		
		
		
		// To test your swapPairs method, convert the following to ArrayLists of Strings and 
		// pass them into your swapPairs method.  
		// Expected output:  
		//    score, four, seven, and, ago, years
		//    be, to, not, or, be, to, hamlet
		//    love, I, programming!
		//    straight, Pretty, test, forward, a, with, twist
		//    don't move me
		//    <blank>
		String[] test_swap_1 = {"four", "score", "and", "seven", "years", "ago"};
		String[] test_swap_2 = {"to", "be", "or", "not", "to", "be", "hamlet"};
		String[] test_swap_3 = {"I", "love", "programming!"};
		String[] test_swap_4 = {"Pretty", "straight", "forward", "test", "with", "a", "twist"};
		String[] test_swap_5 = {"don't move me"};
		String[] test_swap_6 = {};

		
		printMe(swapPairs(convertArrayToList(test_swap_1)));
		printMe(swapPairs(convertArrayToList(test_swap_2)));
		printMe(swapPairs(convertArrayToList(test_swap_3)));
		printMe(swapPairs(convertArrayToList(test_swap_4)));
		printMe(swapPairs(convertArrayToList(test_swap_5)));
		printMe(swapPairs(convertArrayToList(test_swap_6)));
		System.out.println();
		// To test your removeEvenLength method, convert the following to ArrayLists of Strings and 
		// pass them into your removeEvenLength method.  
		// Expected output:  
		//    is, test
		//    odd, o
		//    you, it, what?
		//    <blank>
		String[] test_rem_1 = {"This", "is", "a", "test"};
		String[] test_rem_2 = {"even", "odd", "ev", "o"};
		String[] test_rem_3 = {"Did", "you", "solve", "it", "or", "what?"};
		String[] test_rem_4 = {};
				
		printMe(removeEvenLength(convertArrayToList(test_rem_1)));
		printMe(removeEvenLength(convertArrayToList(test_rem_2)));
		printMe(removeEvenLength(convertArrayToList(test_rem_3)));
		printMe(removeEvenLength(convertArrayToList(test_rem_4)));
		System.out.println();
		
		// To test your doubleList method, convert the following to ArrayLists of Strings and 
		// pass them into your doubleList method.  
		// Expected output:  
		//    how, how, are, are, you?, you?
		//    I, I, am, am, great,, great,, thanks!, thanks!
		//    One string only, One string only
		//    1, 1, 4, 4, 3, 3
		//    <blank>
		String[] test_doub_1 = {"how", "are", "you?"};
		String[] test_doub_2 = {"I", "am", "great,", "thanks!"};
		String[] test_doub_3 = {"One string only"};		
		String[] test_doub_4 = {"1", "4", "3"};	
		String[] test_doub_5 = {};		
		
		printMe(doubleList(convertArrayToList(test_doub_1)));
		printMe(doubleList(convertArrayToList(test_doub_2)));
		printMe(doubleList(convertArrayToList(test_doub_3)));
		printMe(doubleList(convertArrayToList(test_doub_4)));
		printMe(doubleList(convertArrayToList(test_doub_5)));
	}
		
		


}

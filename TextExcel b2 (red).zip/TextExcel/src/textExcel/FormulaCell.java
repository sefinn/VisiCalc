package textExcel;

public class FormulaCell extends RealCell
{
	
	private String input;
	
	private Spreadsheet spread;
	
	
	public FormulaCell(String input, Spreadsheet spread)
	{
		
		super(input);
		this.input = input;
		this.spread = spread;
		
	}
	
	
	
	public double getDoubleValue()
	{
	
		double answer = 0;
		String [] pieces = input.split(" ");
		char maybeAlpha = pieces[1].charAt(0);
		
		
		if(Character.isLetter(maybeAlpha))
		{
			
			SpreadsheetLocation loc = new SpreadsheetLocation(pieces[1]);	
			
			Cell referenceValue = spread.getCell(loc);
			RealCell reference = (RealCell) referenceValue;
			
			answer = reference.getDoubleValue();
			
		}
		else
		{
			
			answer = Double.parseDouble(pieces[1]);
			
		}
		
		if(pieces[1].equalsIgnoreCase("avg"))
		{
			
		}
		
		
		if(pieces[1].equalsIgnoreCase("sum"))
		{
			
		}
		
		
		
		
		for(int i = 1; i < pieces.length - 3; i += 2)
		{
			
			double value = 0;
			
			
			
			maybeAlpha = pieces[i + 2].charAt(0);
			
			
			

			
			
			if(Character.isLetter(maybeAlpha))
			{
				System.out.println("test");	
				SpreadsheetLocation loc = new SpreadsheetLocation(pieces[i + 2]);	
										
				Cell referenceValue = spread.getCell(loc);
				RealCell reference = (RealCell) referenceValue;
				
				value = reference.getDoubleValue();
				
				
			}
			
			
			
			
			if(!Character.isLetter(maybeAlpha))
			{
				
				value = Double.parseDouble(pieces[i + 2]);
				
			}
			
			if(pieces[i + 1].equals("+"))
			{
				
				answer += value;
			}
			if(pieces[i + 1].equals("-"))
			{
				answer -= value;
			}
			if(pieces[i + 1].equals("*") || pieces[i + 1].equals("x"))
			{
				answer *= value;
			}
			if(pieces[i + 1].equals("/"))
			{
				answer /= value;
			}
			if(pieces.length == 3)
			{
				answer = value;
			}
		}
		
		return answer;
	}
	
	
	public String abbreviatedCellText()
	{
		
		double answer = getDoubleValue();
		return Spreadsheet.fitIntoCell(answer + "");
	}
	
	public String fullCellText()
	{
		return input;
	}
}

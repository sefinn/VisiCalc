public class ShapeTest {

	private Shape[] shapes;
	
	public void createShapes()
	{
		Point p1 = new Point (0,0);
		Point p2 = new Point (5,0);
		Point p3 = new Point (15,0);
		Point p4 = new Point (25,0);
		Point p5 = new Point (0,30);
		Point p6 = new Point (0,60);
		
		Shape r1 = new Rectangle(2,5,p1);
		Shape r2 = new Rectangle(3,3,p2);
		Shape rp1 = new RectPrism(10,8,9,p3);
		Shape rp2 = new RectPrism(10,10,10,p4);
		Shape c1 = new Circle(5,p5);
		Shape cy1 = new Cylinder(5,10,p6);
		
		shapes[0] = r1;
		shapes[1] = r2;
		shapes[2] = rp1;
		shapes[3] = rp2;
		shapes[4] = c1;
		shapes[5] = cy1;
	}
	
	public void useShapes()
	{
		for(Shape s : shapes)
		{
			s.getName();
			s.toString();
			s.area();
		}
	}
	
	public void thirdAndSixth()
	{
		System.out.println("The volume of the third shape is " + shapes[2].volume());
		System.out.println("The volume of the sixth shape is " + shapes[5].volume());
	}
	
	public static void main(String[] args)
	{
		ShapeTest tester = new ShapeTest();
		tester.createShapes();
		tester.useShapes();
		tester.thirdAndSixth();
	}
}

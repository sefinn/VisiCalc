
public class Rectangle extends Shape
{
	private double length;
	private double width;
	private Point corner;
	
	
	
	public Rectangle(double l, double w, Point c)
	{
		length = l;
		width = w;
		corner = c;
	}
	
	public double area()
	{
		return length * width;
	}
	
	public double volume()
	{
		return 0;
		//rectangles have not volume, because they have no third dimension.
	}
	
	public String toString()
	{
		return "Length = " + length + " Width = " + width + " Corner = " + corner.toString();
	}
	
	public String getName()
	{
		if(length == width)
		{
			return "Square";
		}
		else
		{
			return "Rectangle";
		}
	}
	
	public double getLength()
	{
		return length;
	}
	
	public double getWidth()
	{
		return width;
	}
	
	public Point getPoint()
	{
		return corner;
	}
	
	
	
}

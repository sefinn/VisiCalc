
public class RectPrism extends Rectangle
{
	
	private double height;
	
	public RectPrism(double h, double l, double w, Point p)
	{
		super(l,w,p);
		height = h;
	}
	
	public double area()
	{
		return 2 * (getWidth() * getLength() + height * getLength() + height * getWidth());
	}
	
	public double volume()
	{
		return height * getWidth() * getLength();
	}
	
	public String getName()
	{
		if(getLength() == height && height == getWidth())
		{
			return "Cube";
		}
		
		if(height == 0 || getLength() == 0 || getWidth() == 0)
		{
			return "Rectangle";
		}
		
		else
		{
			return "Rectangular Prism";
		}
	}
	
	public String toString()
	{
		return "Length = " + getLength() + "Width = " + getWidth() + "Height = " + height + "Corner = " + getPoint();
	}
}


public abstract class Shape {

	private static int counter = 0;
	private int idNumber;
	
	public Shape()
	{
		counter++;
		idNumber = counter;
	}
	
	public int getidNumber()
	{
		return this.idNumber;
	}
	
	public double area()
	{
		return 0;
	}
	
	public abstract double volume();
	
	public abstract String getName();
}


public class Complex {
	private int real;
	private int imag;
	private int quadrant;

	

	
	Complex(int real, int imag)
	{
		this.real = real;
		this.imag = imag;
	}
		
	public int getQuadrant()	
	{
		if((real > 0) && (imag > 0 ))
		{
			this.quadrant = 1;
		}
	
		else if((real > 0) && (imag < 0))
		{
			this.quadrant = 2;
		}
	
		else if ((real < 0) && (imag > 0))
		{
			this.quadrant = 4;
		}
	
		else if((real < 0) && (imag < 0))
		{
			this.quadrant = 3;
		}
	return quadrant;
	}		

	
	
	
	public int getReal()
	{
		return real;
	}
	
	public int getImag()
	{
		return imag;
	}
	
	public void setReal(int r)
	{
		real = r;
	}
	
	public void setImag(int i)
	{
		imag = i;
	}
	
	public Complex add(Complex other)
	{
		int sumReal = this.real + other.getReal();
		int sumImag = this.imag + other.getImag();
		Complex sum = new Complex(sumReal, sumImag);
		return sum;
	}
	
	public Complex multBy(Complex other)
	{
		int multReal = (this.real * other.getReal()) - (this.imag * other.getImag());
		int multImag = (this.real * this.imag) + (other.getReal() + other.getImag());
		Complex product = new Complex(multReal, multImag);
		return product;
	}
	
	public String toString()
	{
		String getString = this.real + " + " + this.imag + "i";
		return getString;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

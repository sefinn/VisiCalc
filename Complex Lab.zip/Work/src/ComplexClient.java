public class ComplexClient 
{

	public static void main(String[] args) 
	{
		Complex c1 = new Complex(4, -3);
		Complex c2 = new Complex(1, 2);
		
		Complex c3 = c1.add(c2);
		System.out.print("Sum of c1 and c2:  \t");
		System.out.println(c3);
		
		System.out.println("That's in quadrant " + c3.getQuadrant());
		System.out.println();
		
		Complex c4 = c1.multBy(c2);
		System.out.println("Product of c1 and c2: \t" + c4);
		
		System.out.println("That's in quadrant " + c4.getQuadrant());
		System.out.println();
		
		Complex c5 = new Complex(3,4);
		System.out.println("The empty constructor builds this:  " + c5);
		c5.setReal(-2);
		c5.setImag(-6);
		System.out.println("Now it has been moved to: \t" + c5);
		System.out.println("That's in quadrant " + c5.getQuadrant());
		
	}

}
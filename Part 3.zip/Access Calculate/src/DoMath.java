
public class DoMath {
	
	public static void main(String[] args) 
	{
		System.out.println(Calculate.square(4));
		System.out.println(Calculate.cube(4));
		System.out.println(Calculate.average(4,6));
		System.out.println(Calculate.average(4,0,9));
		System.out.println(Calculate.toDegrees(3.14159));
		System.out.println(Calculate.toRadians(180));
		System.out.println(Calculate.discriminant(10,5,6));
		System.out.println(Calculate.toImproperFrac(4,5,8));
		System.out.println(Calculate.toMixedNum(7,2));
		System.out.println(Calculate.foil(2,3,6,-7,"n"));
		System.out.println(Calculate.toImproperFrac(3,1,2));
		System.out.println(Calculate.isDivisibleBy(1000,10001));
		System.out.println(Calculate.absValue(-4.5));
		System.out.println(Calculate.max(1000,999));
		System.out.println(Calculate.max2(2,3.03864,1));
		System.out.println(Calculate.min(4,0));
		System.out.println(Calculate.round2(0.126));
		System.out.println(Calculate.exp(4,0));
		System.out.println(Calculate.isPrime(17));
		System.out.println(Calculate.gcf(15, 35));
		System.out.println(Calculate.sqrt(81));
		
		
	}
}

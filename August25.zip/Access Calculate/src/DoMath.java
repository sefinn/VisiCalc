
public class DoMath {
	
	public static void main(String[] args) 
	{
		System.out.println(Calculate.square(7));
		
	}
}

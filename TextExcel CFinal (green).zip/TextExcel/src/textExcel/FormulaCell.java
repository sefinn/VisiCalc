package textExcel;

public class FormulaCell extends RealCell
{
	
	private String input;
	private Spreadsheet spread;
	
	public FormulaCell(String input, Spreadsheet spread)
	{
		
		super(input);
		this.input = input;
		this.spread = spread;	
		
	}
	
	
	public double getDoubleValue()
	{
		
		String [] pieces = input.split(" ");
		double answer = 0;
		
		
		
		if(pieces[1].equalsIgnoreCase("avg"))
		{
			
			String[] bounds = pieces[2].split("-");
			String start = bounds[0];
			String end = bounds[1];
			
			int count = 0;
			
			Location startLoc = new SpreadsheetLocation(start);
			Location endLoc = new SpreadsheetLocation(end);
			
			double sum = 0;
			
			
			
			for(int r = startLoc.getRow(); r <= endLoc.getRow(); r++)
			{
				for(int c = startLoc.getCol(); c <= endLoc.getCol(); c++)
				{
					Location loc = new SpreadsheetLocation(r,c);
				
					RealCell cell = (RealCell)spread.getCell(loc);
					
					sum += cell.getDoubleValue();
					
					count++;
						
				}
			}
				
			return sum / count;
		}
		
		
		
		if(pieces[1].equalsIgnoreCase("sum"))
		{
			String[] bounds = pieces[2].split("-");
			String start = bounds[0];
			String end = bounds[1];
			
			SpreadsheetLocation startLoc = new SpreadsheetLocation(start);
			SpreadsheetLocation endLoc = new SpreadsheetLocation(end);
			
			
			
			double sum = 0;
			
			for(int r = startLoc.getRow(); r <= endLoc.getRow(); r++)
			{
				for(int c = startLoc.getCol(); c <= endLoc.getCol(); c++)
				{
					Location loc = new SpreadsheetLocation(r,c);
					
					RealCell cell = (RealCell)spread.getCell(loc);
					
					sum += cell.getDoubleValue();
					/*
					String alpha = "ABCDEFGHIJKL";
					String in = alpha.substring(c, c + 1) + r;
					Location loc = new SpreadsheetLocation(in);
					
					RealCell cell = (RealCell)spread.getCell(loc);
					
					sum += cell.getDoubleValue();
					
					double referenceValue = spread[r][c].getDoubleValue();
					RealCell reference = (RealCell) referenceValue;
					sum += reference.getDoubleValue();
					*/
				}
			}
			return sum;	
		}
		else
		{
			answer = checkReference(pieces[1]);
			
			
			if(pieces.length == 3)
			{
				return answer;
			}
			
			for(int i = 1; i < pieces.length - 3; i += 2)
			{
				
				double value = checkReference(pieces[i + 2]);
				
				

				if(pieces[i + 1].equals("+"))
				{
					answer += value;
				}
				if(pieces[i + 1].equals("-"))
				{
					answer -= value;
				}
				if(pieces[i + 1].equals("*") || pieces[i + 1].equals("x"))
				{
					answer *= value;
				}
				if(pieces[i + 1].equals("/"))
				{
					answer /= value;
				}
				
			}	
			return answer;
		}
	}
	
	
	
	
	public double checkReference(String piece)
	{
		char maybeAlpha = piece.charAt(0);
		double value = 0;
		if(Character.isLetter(maybeAlpha))
		{
			SpreadsheetLocation loc = new SpreadsheetLocation(piece);
			Cell referenceValue = spread.getCell(loc);
			RealCell reference = (RealCell) referenceValue;
			value = reference.getDoubleValue();
		}
		if(!Character.isLetter(maybeAlpha))
		{
			value = Double.parseDouble(piece);	
		}
		return value;
	}
	
	public String abbreviatedCellText()
	{
		
		double answer = getDoubleValue();
		return Spreadsheet.fitIntoCell(answer + "");
	}
	
	public String fullCellText()
	{
		return input;
	}
}

package fracCalc;
import java.util.Arrays;
import java.util.Scanner;


public class FracCalc {

	private int whole;
	private int numer;
	private int denom;
	
	public FracCalc(int whole, int numer, int denom)
	{
		whole = 0;
		numer = 0;
		denom = 0;
	}
    
    // ** IMPORTANT ** DO NOT DELETE THIS FUNCTION.  This function will be used to test your code
    // This function takes a String 'input' and produces the result
    //
    // input is a fraction string that needs to be evaluated.  For your program, this will be the user input.
    //      e.g. input ==> "1/2 + 3/4"
    //        
    // The function should return the result of the fraction after it has been calculated
    //      e.g. return ==> "1_1/4"
    public static String produceAnswer(String input)
    { 
    	
    	String[] operand = input.split(" ");
    	
    		
    		String firstFrac = operand[0];
    		String operator = operand[1];
    		String secondFrac = operand[2];
    	

    	String[] numParts = operand[2].split("_");
    	
    
    	
    	if((numParts.length == 1) && (numParts[0].contains("/")))
    	{
    		String[] fracParts = numParts[0].split("/");
    		String numerator = fracParts[0];
    		String denom = fracParts[1];
    		String soFar = "whole:0 numerator:" + numerator + " denominator:" + denom;
    		return soFar;
    	}
    	
    	else if(numParts.length == 1)
    	{
    		String soFar = "whole:" + operand[2] + " numerator:0 denominator:1";
    		return soFar;
    	}
    	
    	else
    	{
    		String wholeNum = numParts[0];
    		String[] fracParts = numParts[1].split("/");
    		String numerator = fracParts[0];
    		String denom = fracParts[1];
    		
    		String soFar = "whole:" + wholeNum + " numerator:" + numerator + " denominator:" + denom;
    		return soFar;
    		
    		
    	}
        // TODO: Implement this function to produce the solution to the input
      
    }

    // TODO: Fill in the space below with any helper methods that you think you will need
    
}

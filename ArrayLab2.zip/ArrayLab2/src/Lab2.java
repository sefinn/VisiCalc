import java.util.Arrays;

public class Lab2 {

	// This method switches the first and last elements in the given array and then prints 
	// the array.
	public static void swapFirstLast(int[] arr)
	{
		
		int temp = arr[0] ;
		
		arr[0] = arr[(arr.length - 1)];
		
		arr[(arr.length - 1)] = temp;
		
		System.out.println(Arrays.toString(arr));
	}
	
	
	// This method takes in an array and prints its reverse
	public static void reverse(int[] arr)
	{
		
			for(int i = 0; i < arr.length / 2; i++)	
			{
				int x = arr[i];
				int tempX = arr[i];
				int y = arr[arr.length - i - 1];
			
				arr[x - 1] = y;
				arr[y - 1] = x;
			
			
				
			}
		
		
			
		
		System.out.println(Arrays.toString(arr));
		
	}
	
	
	// This method accepts a String and uses the String method split() to split
	// the String on spaces.  Remember that String.split returns an array.
	// The method should then find the target String in the array and replace every 
	// instance of it.  Finally, use your adjusted array to rebuild a String and print it.
	// Ex.       findAndReplace("There are clouds in the sky","clouds","sheep");
	// Output:   There are sheep in the sky
	public static void findAndReplace(String str,String find,String replace)
	{
		String[] arrayInput = str.split(" ");
	
		String output = "";
		
		for(int i = 0; i < arrayInput.length; i++)
		{
			
			if(arrayInput[i].equals(find));
			{
				arrayInput[i] = replace;
			}
		}
		
		for(int i = 0; i < arrayInput.length; i++)
		{
			output += arrayInput[i] + " ";
		}
		System.out.println(output);
	}
	
	
	public static void main(String[] args) 
	{
		// Swap array elements:  Pass  the following arrays into your swapFirstLast method.
		int[] swp = {3, 9, 21, 24, 27}; 
		int[] swp2 = {2, 4, 6, -5, -3, -1};
		
		
		//swapFirstLast(swp);
		//swapFirstLast(swp2);
		
		
		// Reversing an array:  Pass the following arrays into your reverse method.  
		int[] rev = {1, 2, 3, 4, 5, 6, 7};  // Reversed, it should print [7, 6, 5, 4, 3, 2, 1] 
		int[] rev2 = {1, 2, 3, 4, 5, 6};
		
		//reverse(rev);
		//reverse(rev2);
		
		
		// Find and Replace: Pass the following arrays into your findAndReplace method.  In the first
		//   try replacing one of the fruits with something else.  Then try it again and replace "like"
		//   with something else.  Try it again looking for a word that isn't there.  What should happen?
		String iLike = "I like apples I like bananas I like pineapples I like oranges I like pears";
		String empty = "";
		
		findAndReplace(iLike, "apples", "me");
		
	}

}

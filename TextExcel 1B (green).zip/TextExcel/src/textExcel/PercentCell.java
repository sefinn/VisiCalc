package textExcel;

import java.util.Arrays;

public class PercentCell extends RealCell
{
	
	private String contents;
	private String percent;
	private double inputDouble;
	
	public PercentCell(String contents)
	{
		super(contents);
		percent = contents.substring(0, contents.length() - 1);
		inputDouble = Double.parseDouble(percent) / 100;
		
	}
	
	
	public String fullCellText()
	{
		return inputDouble + "";
	}

	public String abbreviatedCellText()
	{

		if(percent.contains("."))
		{
			
			String[] inCell = percent.split("\\.");
			
			if(inCell[0].length() > 1)
			{
				return Spreadsheet.fitIntoCell(inCell[0] + "%");
			}
			else
			{
				String fit = percent.substring(0,1) + "%";
				return Spreadsheet.fitIntoCell(fit);
			}
		}
		
		else
		{
			
			return Spreadsheet.fitIntoCell(percent + "%");
			
		}
	}
	public double getDoubleValue()
	{
		return inputDouble * 100;
	}
}

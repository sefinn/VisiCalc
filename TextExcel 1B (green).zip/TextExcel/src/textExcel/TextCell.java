package textExcel;

public class TextCell implements Cell
{
	
	private String contents;
	
	public TextCell(String inside)
	{
		contents = inside;
		
	}
	
	public String abbreviatedCellText()
	{
		String contentsAbv = contents.substring(1, contents.length() - 1);
		
		return Spreadsheet.fitIntoCell(contentsAbv);
		
		
		/*
		String ans = "";
		ans = String.format("%-10.10s", contentsAbv);
		return ans; 
		*/
		
	}	
	
	public String fullCellText()
	{
		return contents;
	}
}

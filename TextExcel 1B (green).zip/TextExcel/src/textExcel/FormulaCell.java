package textExcel;

public class FormulaCell extends RealCell
{
	
	private String input;
	private double answer = 0;
	
	public FormulaCell(String input)
	{
		
		super(input);
		this.input = input;
		
	}
	
	public double getDoubleValue()
	{
		
		String [] pieces = input.split(" ");
		
		
		
		answer = Double.parseDouble(pieces[1]);
		
		if(pieces.length == 3)
		{
			
			return answer;
		}
		
		for(int i = 1; i < pieces.length - 1; i += 2)
		{
			if(pieces[i + 1].equals("+"))
			{
				answer += Double.parseDouble(pieces[i + 2]);
			}
			if(pieces[i + 1].equals("-"))
			{
				answer -= Double.parseDouble(pieces[i + 2]);
			}
			if(pieces[i + 1].equals("*") || pieces[i + 1].equals("x"))
			{
				answer *= Double.parseDouble(pieces[i + 2]);
			}
			if(pieces[i + 1].equals("/"))
			{
				answer /= Double.parseDouble(pieces[i + 2]);
			}
		}
		
		return answer;
	}
	
	public String abbreviatedCellText()
	{
		
		getDoubleValue();
		return Spreadsheet.fitIntoCell(answer + "");
	}
	
	public String fullCellText()
	{
		return input;
	}
}

package textExcel;

public class RealCell implements Cell
{

	private String contents;
	
	public RealCell(String contents)
	{
		
		this.contents = contents;
	}
	
	public double getDoubleValue()
	{
		return 0;
	}
	
	public String abbreviatedCellText()
	{
		if(contents.contains("."))
		{
			String[] zeros = contents.split("\\.");
			
			
			for(int i = zeros[1].length() - 1; i >= 0; i--)
			{
				//System.out.println(zeros[1].length());
				if(zeros[1].length() == 1)
				{
					break;
				}
				
				else if(zeros[1].charAt(i) == '0')
				{
					zeros[1] = zeros[1].substring(0, zeros[1].length() - 1);
					System.out.println(contents);
					
				}
				
				else if(zeros[1].charAt(i) != '0')
				{
					break;
				}
			}
			
			return Spreadsheet.fitIntoCell(zeros[0] + "." + zeros[1]);
			
				
			
		}
		else
		{
			return Spreadsheet.fitIntoCell(contents + ".0");
		}
		
	}
	
	
	public String fullCellText()
	{
		return contents;
	}
	
	
}

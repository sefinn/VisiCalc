package textExcel;

public class ValueCell extends RealCell
{

	private String contents;
	
	public ValueCell(String contents)
	{
		
		super(contents);
		this.contents = contents;
	}
	
	
	
	public double getDoubleValue()
	{
		
		return Double.parseDouble(contents);
	}
	
	
}

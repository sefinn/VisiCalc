public class Trio implements MenuItem
{
	
	private Sandwich sandwich;
	private Salad salad;
	private Drink drink;
	
	public Trio(Sandwich s, Salad sal, Drink d)
	{
		sandwich = s;
		salad = sal;
		drink = d;
	}
	
	public String getName()
	{
		return sandwich.getName() + "/" + salad.getName() + "/" + drink.getName() + " Trio";
	}
	
	public double getPrice()
	{
		double sand = sandwich.getPrice();
		double sal = salad.getPrice();
		double d = drink.getPrice();
		
		if((sand <= sal) && (sand <= d))
		{
			return sal + d;
		}
		else if((sal <= sand) && (sal <= d))
		{
			return sand + d;
		}
		else
		{
			return sal + sand;
		}
	}
	
}

public interface MenuItem 
{

	public String getName();
	public double getPrice();
	
	
	public static void main(String[] args)
	{
		Sandwich sandwich1 = new Sandwich("Cheeseburger" , 3.50);
		Sandwich sandwich2 = new Sandwich("Cold Cut" , 2.75);
		Sandwich sandwich3 = new Sandwich("Philly Cheesesteak" , 4.00);
		
		Salad salad1 = new Salad("Caesar Salad", 1.25);
		Salad salad2 = new Salad("Potato Salad", 2.75);
		Salad salad3 = new Salad("Cobb Salad", 3.00);
		
		Drink drink1 = new Drink("Water", 1.00);
		Drink drink2 = new Drink("Coffee", 3.00);
		Drink drink3 = new Drink("Lemonade", 2.75);
		
		Trio trio1 = new Trio(sandwich1, salad1, drink1);
		Trio trio2 = new Trio(sandwich2, salad2, drink2);
		Trio trio3 = new Trio(sandwich3, salad3, drink3);
		
		System.out.println(trio1.getName() + " " + trio1.getPrice());
		System.out.println(trio2.getName() + " " + trio2.getPrice());
		System.out.println(trio3.getName() + " " + trio3.getPrice());
	}
	
}

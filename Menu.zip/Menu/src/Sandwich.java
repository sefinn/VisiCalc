public class Sandwich implements MenuItem
{

	private double price;
	private String sandwich;
	
	public Sandwich(String s, double p)
	{
		sandwich = s;
		price = p;
	}
	
	
	public double getPrice()
	{
		return price;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return sandwich;
	}
	
}
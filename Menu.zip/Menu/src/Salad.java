
public class Salad implements MenuItem
{

	private double price;
	private String salad;
	
	public Salad(String s, double p)
	{
		salad = s;
		price = p;
	}
		
	public double getPrice()
	{
		return price;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return salad;
	}
	
}



public class Drink implements MenuItem
{

	private double price;
	private String drink;
	
	public Drink(String d, double p)
	{
		drink = d;
		price = p;
	}
	
		
	public double getPrice()
	{
		return price;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return drink;
	}
	
}
